package com.test.uas.Models;

public class SearchArrayObject {
    String id ="";
    String title ="";
    String year ="";
    String score ="";
    String score_average ="";
    String type ="";
    String imdbid ="";
    String tmdbid ="";
    String traktid ="";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getScore_average() {
        return score_average;
    }

    public void setScore_average(String score_average) {
        this.score_average = score_average;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImdbid() {
        return imdbid;
    }

    public void setImdbid(String imdbid) {
        this.imdbid = imdbid;
    }

    public String getTmdbid() {
        return tmdbid;
    }

    public void setTmdbid(String tmdbid) {
        this.tmdbid = tmdbid;
    }

    public String getTraktid() {
        return traktid;
    }

    public void setTraktid(String traktid) {
        this.traktid = traktid;
    }
}
