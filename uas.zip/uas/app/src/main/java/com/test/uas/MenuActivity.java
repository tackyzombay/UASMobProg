package com.test.uas;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class MenuActivity extends FragmentActivity implements OnMapReadyCallback {


    GoogleMap map;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;

        LatLng CGPAlpha = new LatLng(-6.193924061113853, 106.78813220277623);
        map.addMarker(new MarkerOptions().position(CGPAlpha).title("CGP Alpha"));
        map.moveCamera(CameraUpdateFactory.newLatLng(CGPAlpha));

        LatLng CGPBeta = new LatLng(-6.20175020412279, 106.78223868546155);
        map.addMarker(new MarkerOptions().position(CGPBeta).title("CGP Beta"));
        map.moveCamera(CameraUpdateFactory.newLatLng(CGPBeta));
    }
}