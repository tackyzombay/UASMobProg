package com.test.uas.Models;

import java.util.List;

public class SearchApiResponse {
    List<SearchArrayObject> search = null;

    public List<SearchArrayObject> getSearch() {
        return search;
    }

    public void setSearch(List<SearchArrayObject> search) {
        this.search = search;
    }
}
